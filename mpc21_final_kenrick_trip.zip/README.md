# Ball Balancing Plate
This is a project for the course 'SC42125: Model Predictive Control' at the Delft University of Technology
In this project various approaches to MPC are used to stabilize and freely control a ball balanced on a actuted plate.

## Students
- Laurens Hoogenboom (4609638)
- Kenrick Trip (4661826)

## Dependancies
- MATLAB
- YALMIP

## Instructions
Any Script in the main folder can be ran by itself if YALMIP is added to path. ./misc/addYalmip.m does this automatically for linux systems assuming this repo is cloned in ~/git/.
YALMIP is also assumed to be cloned in this directory.
