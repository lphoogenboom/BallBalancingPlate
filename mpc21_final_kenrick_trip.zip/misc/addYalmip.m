addpath('~/git/YALMIP/');
addpath('~/git/YALMIP/extras/');
addpath('~/git/YALMIP/solvers/');
addpath('~/git/YALMIP/modules/');
addpath('~/git/YALMIP/operators/');